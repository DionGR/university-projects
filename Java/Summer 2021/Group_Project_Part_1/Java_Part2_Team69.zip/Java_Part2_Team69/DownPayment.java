/*
SUBCLASS of EmployeeActivity
This is the class used for creating DownPayment objects.
 */
public class DownPayment extends EmployeeActivity{

    public DownPayment(Employee employee, double value){
        super(employee, value);
    }// Constructor.
}
